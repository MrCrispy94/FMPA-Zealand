
import React, { useState } from 'react';
import { Habit, ScheduleItem, Meal, DiaryEntry, IconName } from '../types';
import { Icon, CheckCircle, XCircle, Plus, BookOpen, Briefcase, Apple } from './icons';
import Modal from './Modal';

interface DashboardProps {
  habits: Habit[];
  toggleHabit: (id: number) => void;
  addHabit: (habit: Omit<Habit, 'id' | 'completed'>) => void;
  schedule: ScheduleItem[];
  toggleScheduleItem: (id: number) => void;
  meals: Meal[];
  latestEntry?: DiaryEntry;
}

const HabitItem: React.FC<{ habit: Habit; onToggle: () => void; }> = ({ habit, onToggle }) => (
    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
        <div className="flex items-center">
            <Icon name={habit.icon} className="w-6 h-6 text-slate-500" />
            <span className="ml-3 text-slate-700 font-medium">{habit.name}</span>
        </div>
        <button onClick={onToggle} className="transition-transform duration-200 ease-in-out hover:scale-110">
            {habit.completed ? <CheckCircle className="w-7 h-7 text-green-500" /> : <div className="w-7 h-7 rounded-full border-2 border-slate-300 bg-white"></div>}
        </button>
    </div>
);


const AddHabitForm: React.FC<{ addHabit: (habit: Omit<Habit, 'id'| 'completed'>) => void; onClose: () => void; }> = ({ addHabit, onClose }) => {
    const [name, setName] = useState('');
    const [icon, setIcon] = useState<IconName>('Sun');
    
    const availableIcons: IconName[] = ['Sun', 'BookOpen', 'GlassWater', 'Dumbbell', 'Briefcase', 'Apple'];

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim()) {
            addHabit({ name, icon });
            onClose();
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="habitName" className="block text-sm font-medium text-slate-700">Habit Name</label>
                <input
                    type="text"
                    id="habitName"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="e.g. Morning Run"
                    required
                />
            </div>
            <div>
                 <label className="block text-sm font-medium text-slate-700">Icon</label>
                 <div className="mt-2 grid grid-cols-6 gap-2">
                     {availableIcons.map(iconName => (
                         <button key={iconName} type="button" onClick={() => setIcon(iconName)} className={`p-2 rounded-lg flex justify-center items-center transition-all ${icon === iconName ? 'bg-blue-500 text-white ring-2 ring-offset-2 ring-blue-500' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                            <Icon name={iconName} className="w-6 h-6"/>
                         </button>
                     ))}
                 </div>
            </div>
            <div className="flex justify-end pt-2">
                <button type="submit" className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Add Habit
                </button>
            </div>
        </form>
    );
};

const Dashboard: React.FC<DashboardProps> = ({ habits, toggleHabit, addHabit, schedule, toggleScheduleItem, meals, latestEntry }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const totalCalories = meals.reduce((sum, meal) => sum + meal.calories, 0);

  return (
    <div className="space-y-6">
        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add New Habit">
            <AddHabitForm addHabit={addHabit} onClose={() => setIsModalOpen(false)} />
        </Modal>

      <h1 className="text-3xl font-bold text-slate-800">Today's Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {/* Summary Cards */}
          <div className="bg-white p-5 rounded-xl shadow-md flex items-center justify-between">
              <div>
                  <p className="text-sm font-medium text-slate-500">Habits Completed</p>
                  <p className="text-3xl font-bold text-slate-800">{habits.filter(h => h.completed).length} / {habits.length}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <CheckCircle className="w-6 h-6 text-blue-600"/>
              </div>
          </div>
          <div className="bg-white p-5 rounded-xl shadow-md flex items-center justify-between">
              <div>
                  <p className="text-sm font-medium text-slate-500">Tasks Due</p>
                  <p className="text-3xl font-bold text-slate-800">{schedule.filter(s => !s.completed).length}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <Briefcase className="w-6 h-6 text-green-600"/>
              </div>
          </div>
          <div className="bg-white p-5 rounded-xl shadow-md flex items-center justify-between">
              <div>
                  <p className="text-sm font-medium text-slate-500">Calories Intake</p>
                  <p className="text-3xl font-bold text-slate-800">{totalCalories}</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-full">
                <Apple className="w-6 h-6 text-orange-600"/>
              </div>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        
        {/* Habit Tracker */}
        <div className="bg-white p-6 rounded-xl shadow-md xl:col-span-1">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-slate-800">Habit Tracker</h2>
            <button onClick={() => setIsModalOpen(true)} className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-800">
                <Plus className="w-4 h-4 mr-1"/> Add New
            </button>
          </div>
          <div className="space-y-3">
             {habits.map(habit => <HabitItem key={habit.id} habit={habit} onToggle={() => toggleHabit(habit.id)} />)}
          </div>
        </div>

        {/* Schedule */}
        <div className="bg-white p-6 rounded-xl shadow-md xl:col-span-1">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Today's Schedule</h2>
          <div className="space-y-3">
            {schedule.map(item => (
              <div key={item.id} className="flex items-center">
                 <button onClick={() => toggleScheduleItem(item.id)}>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center mr-3 ${item.completed ? 'bg-green-500' : 'border-2 border-slate-300'}`}>
                        {item.completed && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 9"><path d="M1 4.5L4.5 8L11 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                    </div>
                 </button>
                 <div className="flex-1">
                    <p className={`font-medium ${item.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>{item.task}</p>
                    <p className="text-sm text-slate-500">{item.time}</p>
                 </div>
              </div>
            ))}
          </div>
        </div>

        {/* Latest Diary Entry */}
        <div className="bg-white p-6 rounded-xl shadow-md xl:col-span-1">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Latest Diary Entry</h2>
          {latestEntry ? (
            <div className="space-y-3">
              {latestEntry.image && <img src={latestEntry.image} alt={latestEntry.title} className="rounded-lg w-full h-40 object-cover" />}
              <h3 className="font-bold text-lg text-slate-800">{latestEntry.title}</h3>
              <p className="text-slate-600 text-sm line-clamp-3">{latestEntry.content}</p>
              <button onClick={() => {}} className="font-medium text-sm text-blue-600 hover:underline">Read more</button>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
                <BookOpen className="w-12 h-12 mx-auto mb-2"/>
                No entries yet.
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default Dashboard;