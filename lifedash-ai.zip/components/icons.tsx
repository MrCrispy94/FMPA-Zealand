
import React from 'react';

interface IconProps {
  className?: string;
}

export const Home: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>
  </svg>
);

export const BookOpen: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
  </svg>
);

export const Apple: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 20.94c1.5 0 2.75 1.06 4 0c1.25-1.06 2.5-2.25 2.5-4.38c0-2.25-1.5-4-3-4c-1.5 0-2.5 1-3.5 1c-1 0-2-1-3.5-1c-1.5 0-3 1.75-3 4c0 2.13 1.25 3.32 2.5 4.38c1.25 1.06 2.5 0 4 0Z"></path><path d="M12 20.94c1.5 0 2.75 1.06 4 0c1.25-1.06 2.5-2.25 2.5-4.38c0-2.25-1.5-4-3-4c-1.5 0-2.5 1-3.5 1c-1 0-2-1-3.5-1c-1.5 0-3 1.75-3 4c0 2.13 1.25 3.32 2.5 4.38c1.25 1.06 2.5 0 4 0Z"></path><path d="M12 4a2 2 0 0 0-2-2a2 2 0 0 0-2 2"></path>
    </svg>
);

export const Briefcase: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
  </svg>
);

export const Sun: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path>
    </svg>
);

export const GlassWater: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M15 2H9s-1 1-1 3v13c0 1.1.9 2 2 2h4c1.1 0 2-.9 2-2V5c0-2-1-3-1-3z"></path><path d="M9 13h6"></path>
    </svg>
);

export const Dumbbell: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="m6.5 6.5 11 11"></path><path d="m21 21-1-1"></path><path d="m3 3 1 1"></path><path d="m18 22 4-4"></path><path d="m6 2-4 4"></path><path d="m18.5 3.5 2 2"></path><path d="m3.5 18.5 2 2"></path><path d="m15 6-4-4"></path><path d="m9 18 4 4"></path>
    </svg>
);

export const BrainCircuit: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 5a3 3 0 1 0-5.99 1.13"></path><path d="M12 5a3 3 0 1 1 5.99 1.13"></path><path d="M15 12a3 3 0 1 0-5.99 1.13"></path><path d="M15 12a3 3 0 1 1 5.99 1.13"></path><path d="M9 12a3 3 0 1 0-5.99-1.13"></path><path d="M9 12a3 3 0 1 1 5.99-1.13"></path><path d="M12 19a3 3 0 1 0-5.99 1.13"></path><path d="M12 19a3 3 0 1 1 5.99 1.13"></path><path d="M12 12v7"></path><path d="m15 9-3-4"></path><path d="m9 9 3-4"></path>
    </svg>
);

export const Plus: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

export const CheckCircle: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path><path d="m9 12 2 2 4-4"></path>
    </svg>
);

export const XCircle: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>
    </svg>
);

export const Camera: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path><circle cx="12" cy="13" r="3"></circle>
    </svg>
);

export const Trash2: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><path d="M10 11v6"></path><path d="M14 11v6"></path>
    </svg>
);

const iconMap: Record<string, React.FC<IconProps>> = {
  Sun,
  BookOpen,
  GlassWater,
  Briefcase,
  Apple,
  Dumbbell,
  BrainCircuit,
  Plus,
};

interface IconNameToComponentProps extends IconProps {
    name: string;
}

export const Icon: React.FC<IconNameToComponentProps> = ({ name, className }) => {
    const IconComponent = iconMap[name];
    return IconComponent ? <IconComponent className={className} /> : null;
};