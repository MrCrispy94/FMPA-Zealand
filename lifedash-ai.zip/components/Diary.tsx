
import React, { useState } from 'react';
import { DiaryEntry } from '../types';
import { Plus, Camera, BookOpen } from './icons';
import Modal from './Modal';

interface DiaryProps {
  entries: DiaryEntry[];
  addEntry: (entry: Omit<DiaryEntry, 'id'>) => void;
}

const AddEntryForm: React.FC<{ addEntry: (entry: Omit<DiaryEntry, 'id'>) => void; onClose: () => void; }> = ({ addEntry, onClose }) => {
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [image, setImage] = useState<string | null>(null);
    const [imageName, setImageName] = useState<string>('');

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setImageName(file.name);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImage(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (title.trim() && content.trim()) {
            addEntry({ title, content, image, date: new Date().toISOString() });
            onClose();
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="entryTitle" className="block text-sm font-medium text-slate-700">Title</label>
                <input
                    type="text"
                    id="entryTitle"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="A memorable day"
                    required
                />
            </div>
            <div>
                <label htmlFor="entryContent" className="block text-sm font-medium text-slate-700">Content</label>
                <textarea
                    id="entryContent"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    rows={4}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="What's on your mind?"
                    required
                ></textarea>
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-700">Add Image (Optional)</label>
                <label htmlFor="imageUpload" className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 border-dashed rounded-md cursor-pointer hover:border-blue-500 transition">
                    <div className="space-y-1 text-center">
                         <Camera className="mx-auto h-12 w-12 text-slate-400" />
                        <div className="flex text-sm text-slate-600">
                            <p className="pl-1">
                                {imageName ? imageName : 'Upload a file or drag and drop'}
                            </p>
                        </div>
                        <p className="text-xs text-slate-500">PNG, JPG, GIF up to 10MB</p>
                    </div>
                    <input id="imageUpload" name="imageUpload" type="file" className="sr-only" onChange={handleImageChange} accept="image/*" />
                </label>
                 {image && <img src={image} alt="Preview" className="mt-4 rounded-md max-h-40 mx-auto" />}
            </div>
            <div className="flex justify-end pt-2">
                <button type="submit" className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Save Entry
                </button>
            </div>
        </form>
    );
};


const Diary: React.FC<DiaryProps> = ({ entries, addEntry }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="New Diary Entry">
          <AddEntryForm addEntry={addEntry} onClose={() => setIsModalOpen(false)} />
      </Modal>

      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-slate-800">My Diary</h1>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg shadow-md transition-transform transform hover:scale-105">
          <Plus className="w-5 h-5 mr-2"/>
          New Entry
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {entries.map(entry => (
          <div key={entry.id} className="bg-white rounded-xl shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
            {entry.image && <img src={entry.image} alt={entry.title} className="w-full h-48 object-cover" />}
            <div className="p-6">
              <p className="text-sm text-slate-500">{new Date(entry.date).toLocaleDateString()}</p>
              <h2 className="text-xl font-semibold mt-1 text-slate-800">{entry.title}</h2>
              <p className="mt-2 text-slate-600 line-clamp-3">{entry.content}</p>
            </div>
          </div>
        ))}
        {entries.length === 0 && (
            <div className="md:col-span-2 lg:col-span-3 text-center py-16 text-slate-500 bg-white rounded-xl shadow-md">
                <BookOpen className="w-16 h-16 mx-auto mb-4"/>
                <h3 className="text-xl font-semibold">Your diary is empty</h3>
                <p>Click "New Entry" to start writing.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Diary;