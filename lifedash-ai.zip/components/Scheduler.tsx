
import React, { useState } from 'react';
import { ScheduleItem } from '../types';
import { Plus } from './icons';
import Modal from './Modal';

interface SchedulerProps {
  items: ScheduleItem[];
  addItem: (item: Omit<ScheduleItem, 'id' | 'completed'>) => void;
  toggleItem: (id: number) => void;
}

const AddItemForm: React.FC<{ addItem: (item: Omit<ScheduleItem, 'id' | 'completed'>) => void; onClose: () => void; }> = ({ addItem, onClose }) => {
    const [task, setTask] = useState('');
    const [time, setTime] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (task.trim() && time.trim()) {
            addItem({ task, time });
            onClose();
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="taskName" className="block text-sm font-medium text-slate-700">Task</label>
                <input
                    type="text" id="taskName" value={task} onChange={(e) => setTask(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., Finalize presentation" required
                />
            </div>
            <div>
                <label htmlFor="taskTime" className="block text-sm font-medium text-slate-700">Time</label>
                <input
                    type="time" id="taskTime" value={time} onChange={(e) => setTime(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    required
                />
            </div>
            <div className="flex justify-end pt-2">
                <button type="submit" className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">Add Task</button>
            </div>
        </form>
    );
};

const Scheduler: React.FC<SchedulerProps> = ({ items, addItem, toggleItem }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="New Schedule Item">
          <AddItemForm addItem={addItem} onClose={() => setIsModalOpen(false)} />
      </Modal>

      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-slate-800">Work Scheduler</h1>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg shadow-md transition-transform transform hover:scale-105">
          <Plus className="w-5 h-5 mr-2"/>
          New Task
        </button>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-semibold text-slate-800 mb-4">Today's Tasks</h2>
        <ul className="divide-y divide-slate-200">
          {items.sort((a,b) => a.time.localeCompare(b.time)).map(item => (
            <li key={item.id} className="py-4 flex items-center">
              <button onClick={() => toggleItem(item.id)} className="mr-4">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200 ${item.completed ? 'bg-green-500 border-green-500' : 'border-2 border-slate-300 bg-white'}`}>
                    {item.completed && <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 12 9"><path d="M1 4.5L4.5 8L11 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                </div>
              </button>
              <div className="flex-1 flex items-baseline">
                <span className={`font-mono text-sm font-semibold py-1 px-2 rounded-md mr-4 ${item.completed ? 'bg-slate-100 text-slate-400' : 'bg-blue-100 text-blue-800'}`}>{item.time}</span>
                <p className={`font-medium ${item.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>{item.task}</p>
              </div>
            </li>
          ))}
          {items.length === 0 && (
              <li className="text-center py-8 text-slate-500">No tasks for today. Enjoy your free time!</li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default Scheduler;