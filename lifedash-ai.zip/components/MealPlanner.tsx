
import React, { useState, useMemo } from 'react';
import { Meal, MealType, GeminiMealSuggestion } from '../types';
import { Plus, Trash2, BrainCircuit } from './icons';
import Modal from './Modal';
import { suggestMealFromIngredients } from '../services/geminiService';

interface MealPlannerProps {
  meals: Meal[];
  addMeal: (meal: Omit<Meal, 'id'>) => void;
  removeMeal: (id: number) => void;
}

const AddMealForm: React.FC<{ addMeal: (meal: Omit<Meal, 'id'>) => void; onClose: () => void; }> = ({ addMeal, onClose }) => {
    const [name, setName] = useState('');
    const [calories, setCalories] = useState('');
    const [type, setType] = useState<MealType>(MealType.BREAKFAST);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const cal = parseInt(calories, 10);
        if (name.trim() && !isNaN(cal)) {
            addMeal({ name, calories: cal, type });
            onClose();
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
             <div>
                <label htmlFor="mealName" className="block text-sm font-medium text-slate-700">Meal Name</label>
                <input
                    type="text" id="mealName" value={name} onChange={(e) => setName(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., Apple slices" required
                />
            </div>
            <div>
                <label htmlFor="calories" className="block text-sm font-medium text-slate-700">Calories</label>
                <input
                    type="number" id="calories" value={calories} onChange={(e) => setCalories(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., 95" required
                />
            </div>
             <div>
                <label htmlFor="mealType" className="block text-sm font-medium text-slate-700">Meal Type</label>
                <select id="mealType" value={type} onChange={(e) => setType(e.target.value as MealType)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                    {Object.values(MealType).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
            </div>
            <div className="flex justify-end pt-2">
                <button type="submit" className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">Add Meal</button>
            </div>
        </form>
    );
};

const AiSuggester: React.FC<{ addMeal: (meal: Omit<Meal, 'id'>) => void; }> = ({ addMeal }) => {
    const [ingredients, setIngredients] = useState('');
    const [suggestion, setSuggestion] = useState<GeminiMealSuggestion | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSuggestion = async () => {
        if (!ingredients.trim()) return;
        setIsLoading(true);
        setError('');
        setSuggestion(null);
        try {
            const result = await suggestMealFromIngredients(ingredients);
            setSuggestion(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const addSuggestedMeal = (type: MealType) => {
        if(suggestion) {
            addMeal({ name: suggestion.name, calories: suggestion.calories, type });
            setSuggestion(null);
            setIngredients('');
        }
    }

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
                <BrainCircuit className="w-6 h-6 mr-2 text-blue-600" />
                AI Meal Suggester
            </h2>
            <div className="space-y-4">
                <textarea
                    value={ingredients}
                    onChange={(e) => setIngredients(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter ingredients you have (e.g., chicken breast, rice, broccoli)"
                    rows={3}
                    disabled={isLoading}
                />
                <button
                    onClick={handleSuggestion}
                    disabled={isLoading || !ingredients.trim()}
                    className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 disabled:cursor-not-allowed"
                >
                    {isLoading ? 'Thinking...' : 'Get Suggestion'}
                </button>
                {error && <p className="text-sm text-red-600">{error}</p>}
                {suggestion && (
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 animate-fade-in-up">
                        <h3 className="font-bold text-lg text-slate-800">{suggestion.name}</h3>
                        <p className="text-sm font-medium text-slate-600">{suggestion.calories} calories</p>
                        <p className="mt-2 text-sm text-slate-500">{suggestion.recipe}</p>
                        <div className="mt-4 flex flex-wrap gap-2">
                             {Object.values(MealType).map(type => (
                                <button key={type} onClick={() => addSuggestedMeal(type)} className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded-full hover:bg-blue-300">
                                    Add as {type}
                                </button>
                             ))}
                        </div>
                    </div>
                )}
            </div>
             <style>{`
                @keyframes fade-in-up {
                  from { opacity: 0; transform: translateY(10px); }
                  to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-up { animation: fade-in-up 0.3s ease-out forwards; }
            `}</style>
        </div>
    );
}

const MealPlanner: React.FC<MealPlannerProps> = ({ meals, addMeal, removeMeal }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const mealsByType = useMemo(() => {
    return meals.reduce((acc, meal) => {
        if (!acc[meal.type]) {
            acc[meal.type] = [];
        }
        acc[meal.type].push(meal);
        return acc;
    }, {} as Record<MealType, Meal[]>);
  }, [meals]);

  const totalCalories = useMemo(() => meals.reduce((sum, meal) => sum + meal.calories, 0), [meals]);

  return (
    <div className="space-y-6">
        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add Meal">
            <AddMealForm addMeal={addMeal} onClose={() => setIsModalOpen(false)} />
        </Modal>

        <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-slate-800">Meal Planner</h1>
            <button onClick={() => setIsModalOpen(true)} className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg shadow-md transition-transform transform hover:scale-105">
                <Plus className="w-5 h-5 mr-2"/> Add Meal Manually
            </button>
        </div>

        <AiSuggester addMeal={addMeal} />

        <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-baseline mb-4">
                <h2 className="text-xl font-semibold text-slate-800">Today's Meals</h2>
                <p className="text-lg font-bold text-blue-600">Total: {totalCalories} kcal</p>
            </div>
            <div className="space-y-4">
                {Object.values(MealType).map(type => (
                    mealsByType[type] && mealsByType[type].length > 0 && (
                        <div key={type}>
                            <h3 className="font-semibold text-slate-600 border-b pb-1 mb-2">{type}</h3>
                            <ul className="space-y-2">
                                {mealsByType[type].map(meal => (
                                    <li key={meal.id} className="flex justify-between items-center p-2 bg-slate-50 rounded-md">
                                        <div>
                                            <p className="font-medium text-slate-800">{meal.name}</p>
                                            <p className="text-sm text-slate-500">{meal.calories} kcal</p>
                                        </div>
                                        <button onClick={() => removeMeal(meal.id)} className="text-red-400 hover:text-red-600">
                                            <Trash2 className="w-5 h-5"/>
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )
                ))}
                 {meals.length === 0 && <p className="text-center text-slate-500 py-4">No meals logged yet.</p>}
            </div>
        </div>
    </div>
  );
};

export default MealPlanner;