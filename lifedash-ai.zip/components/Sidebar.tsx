
import React from 'react';
import { View } from '../types';
import { Home, BookOpen, Apple, Briefcase, BrainCircuit } from './icons';

interface SidebarProps {
  currentView: View;
  setCurrentView: (view: View) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 ${
      isActive
        ? 'bg-blue-600 text-white shadow-lg'
        : 'text-slate-600 hover:bg-slate-200 hover:text-slate-900'
    }`}
  >
    {icon}
    <span className="ml-3">{label}</span>
  </button>
);

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView }) => {
  const navItems = [
    { view: View.DASHBOARD, label: 'Dashboard', icon: <Home className="w-5 h-5" /> },
    { view: View.DIARY, label: 'Diary', icon: <BookOpen className="w-5 h-5" /> },
    { view: View.MEAL_PLANNER, label: 'Meal Planner', icon: <Apple className="w-5 h-5" /> },
    { view: View.SCHEDULER, label: 'Scheduler', icon: <Briefcase className="w-5 h-5" /> },
  ];

  return (
    <div className="w-64 bg-white/80 backdrop-blur-sm border-r border-slate-200 flex flex-col p-4 shadow-sm">
      <div className="flex items-center mb-8 px-2">
        <BrainCircuit className="w-8 h-8 text-blue-600" />
        <h1 className="ml-2 text-2xl font-bold text-slate-800">LifeDash</h1>
      </div>
      <nav className="flex flex-col space-y-2">
        {navItems.map((item) => (
          <NavItem
            key={item.view}
            icon={item.icon}
            label={item.label}
            isActive={currentView === item.view}
            onClick={() => setCurrentView(item.view)}
          />
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;