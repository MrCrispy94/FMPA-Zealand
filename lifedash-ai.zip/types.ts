
export enum View {
  DASHBOARD = 'DASHBOARD',
  DIARY = 'DIARY',
  MEAL_PLANNER = 'MEAL_PLANNER',
  SCHEDULER = 'SCHEDULER',
}

export type IconName = 'Sun' | 'BookOpen' | 'GlassWater' | 'Briefcase' | 'Apple' | 'Dumbbell' | 'BrainCircuit' | 'Plus';

export interface Habit {
  id: number;
  name: string;
  icon: IconName;
  completed: boolean;
}

export interface DiaryEntry {
  id: number;
  title: string;
  content: string;
  date: string;
  image?: string | null;
}

export enum MealType {
    BREAKFAST = 'Breakfast',
    LUNCH = 'Lunch',
    DINNER = 'Dinner',
    SNACK = 'Snack',
}

export interface Meal {
  id: number;
  type: MealType;
  name:string;
  calories: number;
}

export interface ScheduleItem {
  id: number;
  time: string;
  task: string;
  completed: boolean;
}

export interface GeminiMealSuggestion {
    name: string;
    calories: number;
    recipe: string;
}