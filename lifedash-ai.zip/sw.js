const CACHE_NAME = 'lifedash-ai-cache-v1';
// This list includes all static assets to be cached for offline use.
const URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/index.tsx',
  '/App.tsx',
  '/types.ts',
  '/metadata.json',
  '/components/Sidebar.tsx',
  '/components/Dashboard.tsx',
  '/components/Diary.tsx',
  '/components/MealPlanner.tsx',
  '/components/Scheduler.tsx',
  '/components/Modal.tsx',
  '/components/icons.tsx',
  '/services/geminiService.ts',
  // App Icons for PWA (ensure these files exist in your root directory)
  '/icon-192.png',
  '/icon-512.png',
  // External assets
  'https://cdn.tailwindcss.com',
  'https://esm.sh/react@^19.1.0',
  'https://esm.sh/react-dom@^19.1.0/client',
  'https://esm.sh/react@^19.1.0/jsx-runtime',
  'https://esm.sh/@google/genai@^1.7.0'
];

// Install event: open cache and add all URLs to it
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(URLS_TO_CACHE);
      })
  );
});

// Fetch event: serve from cache first, then network for GET requests
self.addEventListener('fetch', event => {
  // We only want to cache GET requests.
  // Other requests like POST to Gemini API should pass through.
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        // Not in cache - fetch from network, cache it, and return response
        return fetch(event.request).then(
          networkResponse => {
            // Check if we received a valid response
            if (!networkResponse || networkResponse.status !== 200) {
              return networkResponse;
            }

            // IMPORTANT: Clone the response. A response is a stream
            // and must be cloned to be consumed by both the browser and the cache.
            const responseToCache = networkResponse.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                // We don't cache esm.sh responses as they can be opaque and complex.
                // The browser's native HTTP cache is more effective for them.
                if (!event.request.url.includes('esm.sh')) {
                    cache.put(event.request, responseToCache);
                }
              });

            return networkResponse;
          }
        ).catch(error => {
            console.error('Fetching failed:', error);
            // In a real-world app, you might want to return a custom offline page here.
        });
      })
  );
});


// Activate event: clean up old caches
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
