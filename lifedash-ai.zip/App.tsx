
import React, { useState, useCallback } from 'react';
import { View, Habit, DiaryEntry, Meal, ScheduleItem, MealType } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Diary from './components/Diary';
import MealPlanner from './components/MealPlanner';
import Scheduler from './components/Scheduler';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);

  // Initial App State with sample data
  const [habits, setHabits] = useState<Habit[]>([
    { id: 1, name: 'Morning Jog', icon: 'Sun', completed: true },
    { id: 2, name: 'Read 10 Pages', icon: 'BookOpen', completed: false },
    { id: 3, name: 'Drink 8 glasses of water', icon: 'GlassWater', completed: false },
  ]);

  const [diaryEntries, setDiaryEntries] = useState<DiaryEntry[]>([
    {
      id: 1,
      title: 'A Wonderful Day',
      content: 'Today was a great day. I went for a walk in the park and enjoyed the beautiful weather. It felt refreshing to be out in nature.',
      date: new Date().toISOString(),
      image: 'https://picsum.photos/400/200',
    },
  ]);

  const [meals, setMeals] = useState<Meal[]>([
      { id: 1, type: MealType.BREAKFAST, name: 'Oatmeal with Berries', calories: 350 },
      { id: 2, type: MealType.LUNCH, name: 'Grilled Chicken Salad', calories: 500 },
  ]);

  const [schedule, setSchedule] = useState<ScheduleItem[]>([
    { id: 1, time: '10:00 AM', task: 'Team Meeting', completed: true },
    { id: 2, time: '02:00 PM', task: 'Finish project report', completed: false },
  ]);

  const addHabit = (habit: Omit<Habit, 'id'>) => {
    setHabits(prev => [...prev, { ...habit, id: Date.now() }]);
  };

  const toggleHabit = useCallback((id: number) => {
    setHabits(prev =>
      prev.map(h => (h.id === id ? { ...h, completed: !h.completed } : h))
    );
  }, []);

  const addDiaryEntry = (entry: Omit<DiaryEntry, 'id'>) => {
    setDiaryEntries(prev => [{ ...entry, id: Date.now() }, ...prev]);
  };

  const addMeal = (meal: Omit<Meal, 'id'>) => {
    setMeals(prev => [...prev, { ...meal, id: Date.now() }]);
  };
    
  const removeMeal = (id: number) => {
    setMeals(prev => prev.filter(meal => meal.id !== id));
  };

  const addScheduleItem = (item: Omit<ScheduleItem, 'id'>) => {
    setSchedule(prev => [...prev, { ...item, id: Date.now() }]);
  };

  const toggleScheduleItem = useCallback((id: number) => {
    setSchedule(prev =>
      prev.map(item =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  }, []);

  const renderContent = () => {
    switch (currentView) {
      case View.DIARY:
        return <Diary entries={diaryEntries} addEntry={addDiaryEntry} />;
      case View.MEAL_PLANNER:
        return <MealPlanner meals={meals} addMeal={addMeal} removeMeal={removeMeal} />;
      case View.SCHEDULER:
        return <Scheduler items={schedule} addItem={addScheduleItem} toggleItem={toggleScheduleItem} />;
      case View.DASHBOARD:
      default:
        return <Dashboard 
                  habits={habits} 
                  toggleHabit={toggleHabit} 
                  addHabit={addHabit} 
                  schedule={schedule} 
                  toggleScheduleItem={toggleScheduleItem}
                  meals={meals}
                  latestEntry={diaryEntries[0]}
                />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 font-sans">
      <Sidebar currentView={currentView} setCurrentView={setCurrentView} />
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;