
import { GoogleGenAI } from "@google/genai";
import { GeminiMealSuggestion } from "../types";

// IMPORTANT: Do not expose this key in client-side code in a real application.
// This is for demonstration purposes only. In a real app, this call would be
// made from a secure backend server.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // To prevent app crash in environments where API_KEY is not set.
  // The UI will show an error message.
  console.warn("Gemini API key not found. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });


export const suggestMealFromIngredients = async (ingredients: string): Promise<GeminiMealSuggestion> => {
    if (!API_KEY) {
        throw new Error("API Key is not configured. Cannot get AI suggestions.");
    }

    const prompt = `
        Based on these ingredients: "${ingredients}", suggest a single, simple meal.
        Provide the response as a single, valid JSON object with the following keys and value types:
        - "name": string (the name of the meal)
        - "calories": number (an estimated calorie count)
        - "recipe": string (a brief, one or two-sentence recipe or preparation guide)

        Do not include any other text or markdown formatting outside of the JSON object.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                temperature: 0.7,
            },
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }
        
        const data = JSON.parse(jsonStr);

        // Validate the response structure
        if (typeof data.name === 'string' && typeof data.calories === 'number' && typeof data.recipe === 'string') {
            return data as GeminiMealSuggestion;
        } else {
            throw new Error("AI response was not in the expected format.");
        }
    } catch (e) {
        console.error("Error calling Gemini API:", e);
        throw new Error("Failed to get a suggestion from the AI. Please try again later.");
    }
};
